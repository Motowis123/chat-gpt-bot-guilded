import requests
import openai
from time import sleep

openai.api_key = 'openAI_API_key' #im not 100% sure that you have to pay but yeah

GUILDED_BOT_TOKEN = 'your-guilded-bot-token'
GUILDED_SERVER_ID = 'your-guilded-server-id'
CHANNEL_ID = 'your-channel-id'

BASE_URL = 'https://www.guilded.gg/api/v1'

def get_channel_messages(channel_id, limit=50):
    url = f"{BASE_URL}/channels/{channel_id}/messages"
    headers = {
        "Authorization": f"Bearer {GUILDED_BOT_TOKEN}"
    }
    params = {
        "limit": limit
    }
    response = requests.get(url, headers=headers, params=params)
    if response.status_code == 404:
        print(f"Error: Channel ID {channel_id} not found.")
        return None
    elif response.status_code != 200:
        print(f"Error fetching messages: {response.status_code} - {response.text}")
        return None
    return response.json()

def send_message(channel_id, content):
    url = f"{BASE_URL}/channels/{channel_id}/messages"
    headers = {
        "Authorization": f"Bearer {GUILDED_BOT_TOKEN}",
        "Content-Type": "application/json"
    }
    data = {
        "content": content
    }
    response = requests.post(url, headers=headers, json=data)
    if response.status_code != 201:
        print(f"Error sending message: {response.status_code} - {response.text}")
        return None
    return response.json()

def process_messages(channel_id):
    messages = get_channel_messages(channel_id)
    if not messages or 'messages' not in messages:
        print("No messages found or incorrect response format.")
        return
    
    for message in messages['messages']:
        if message['content'].startswith('+gpt '):
            prompt = message['content'][5:].strip()
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": prompt}
                    ]
                )
                answer = response.choices[0].message['content'].strip()
                send_message(channel_id, answer)
            except openai.error.OpenAIError as e:
                print(f"OpenAI API error: {e}")
                sleep(60)

if __name__ == "__main__":
    print(f"Using CHANNEL_ID: {CHANNEL_ID}")
    
    while True:
        try:
            process_messages(CHANNEL_ID)
        except Exception as e:
            print(f"An error occurred: {e}")
        sleep(5)
