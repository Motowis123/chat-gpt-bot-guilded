chat gpt bot for GUILDED.GG nothing else
the prefix is +gpt <msg can use spaces>   # you dont have to use the <>
Install pip if you havent by typing this in your cmd:
python get-pip.py
And intall openai:
pip install openai
Requires Python, install python here: https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe
PASTE LINK IN BROWSER TO GET RIGHT VERSION
Watch a youtube vid on how tho make a bot and to get the channel and server id turn on developer mode and right click the channel and server and click copy id and put it in the script
 YOU WILL ALSO NEED TO HAVE A OPEN AI API KEY JUST LOOK IT UP ON GOOGLE. TYPE: openAI api key.
You may have to pay idk rlly i had to pay

 __  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
 |  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
 | |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
 | |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
 |_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 